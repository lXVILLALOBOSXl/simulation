package supply.ontology;

import jade.content.*;
import jade.util.leap.*;
import jade.core.*;

/**
* Protege name: Mintel Motherboard
* @author ontology bean generator
* @version 2017/11/28, 20:55:55
*/
public class Mintel_Motherboard extends Component{ 

}
