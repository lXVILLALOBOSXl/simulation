package supply.ontology;

import jade.content.*;
import jade.util.leap.*;
import jade.core.*;

/**
* Protege name: HDD 2TB
* @author ontology bean generator
* @version 2017/11/28, 20:55:56
*/
public class HDD_2TB extends Component{ 

}
