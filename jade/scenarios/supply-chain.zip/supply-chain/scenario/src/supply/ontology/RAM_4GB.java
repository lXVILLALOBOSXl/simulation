package supply.ontology;

import jade.content.*;
import jade.util.leap.*;
import jade.core.*;

/**
* Protege name: RAM 4GB
* @author ontology bean generator
* @version 2017/11/28, 20:55:56
*/
public class RAM_4GB extends Component{ 

}
