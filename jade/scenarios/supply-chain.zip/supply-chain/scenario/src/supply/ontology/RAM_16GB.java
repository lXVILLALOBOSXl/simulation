package supply.ontology;

import jade.content.*;
import jade.util.leap.*;
import jade.core.*;

/**
* Protege name: RAM 16GB
* @author ontology bean generator
* @version 2017/11/28, 20:55:55
*/
public class RAM_16GB extends Component{ 

}
